<?= $this->extend('Templates/auth') ?>

<?= $this->section('title') ?>Verificação de E-mail - Achei Profissional<?= $this->endSection() ?>

<?= $this->section('content') ?>
    <main class="register-section">
        <div class="container">

            <div class="register-card">

                <a href="<?= base_url('register') ?>" class="back-link">
                    <i class="bi bi-arrow-left"></i>
                    Voltar para cadastro
                </a>

                <div class="text-center mb-4">
                    <span class="badge-type">
                        <i class="bi bi-shield-check"></i>
                        Verificação de Segurança
                    </span>

                    <h1 class="welcome-title">
                        Confirme seu e-mail
                    </h1>

                    <p class="welcome-text">
                        Para ativar a sua conta com segurança, precisamos confirmar seu endereço de e-mail.
                    </p>
                </div>

                <!-- Box exibindo o e-mail cadastrado -->
                <div class="email-display-box">
                    <div class="email-display-icon">
                        <i class="bi bi-envelope-at"></i>
                    </div>
                    <div class="email-display-info">
                        <div class="email-display-label">E-mail para envio do código</div>
                        <div class="email-display-value" id="userEmailDisplay" title="<?= esc($email ?? '') ?>">
                            <?= esc($email ?? '') ?>
                        </div>
                    </div>
                </div>

                <!-- Alertas dinâmicos -->
                <div id="alertSuccess" class="alert alert-success py-2 px-3 mb-3 d-none align-items-center gap-2" role="alert">
                    <i class="bi bi-check-circle-fill fs-5 text-success"></i>
                    <span id="alertSuccessMsg" class="small"></span>
                </div>

                <div id="alertError" class="alert alert-danger py-2 px-3 mb-3 d-none align-items-center gap-2" role="alert">
                    <i class="bi bi-exclamation-triangle-fill fs-5 text-danger"></i>
                    <span id="alertErrorMsg" class="small"></span>
                </div>

                <!-- Sessão 1: Botão inicial de envio do código -->
                <div id="sectionEnviarCodigo" class="mb-3">
                    <button
                        type="button"
                        id="btnEnviarCodigo"
                        class="btn-submit d-flex align-items-center justify-content-center gap-2">
                        <i class="bi bi-send"></i>
                        <span id="btnEnviarTexto">Enviar código para meu e-mail</span>
                    </button>
                </div>

                <!-- Sessão 2: Informar código recebido (Exibida após o primeiro envio com sucesso) -->
                <div id="sectionInformarCodigo" class="d-none fade-in">
                    <hr class="my-4" style="border-color: #e5edf4;">

                    <div class="text-center mb-3">
                        <h2 class="h6 fw-bold mb-1 text-dark">
                            Digite o código de verificação
                        </h2>
                        <p class="text-muted small mb-0">
                            Informe os 6 dígitos recebidos na sua caixa de entrada ou spam.
                        </p>
                    </div>

                    <!-- Formulário de validação do código -->
                    <form action="<?= base_url('verificaremail') ?>" method="POST" id="formValidarCodigo">
                        <!-- CSRF Field do CodeIgniter -->
                        <?= csrf_field() ?>

                        <!-- Campo oculto com o código completo concatenado -->
                        <input type="hidden" name="codigo" id="codigoCompleto" value="">

                        <!-- 6 campos individuais de dígitos (OTP) -->
                        <div class="otp-container" id="otpContainer">
                            <input type="text" inputmode="numeric" maxlength="1" class="otp-input" data-index="0" autocomplete="off" aria-label="Dígito 1">
                            <input type="text" inputmode="numeric" maxlength="1" class="otp-input" data-index="1" autocomplete="off" aria-label="Dígito 2">
                            <input type="text" inputmode="numeric" maxlength="1" class="otp-input" data-index="2" autocomplete="off" aria-label="Dígito 3">
                            <input type="text" inputmode="numeric" maxlength="1" class="otp-input" data-index="3" autocomplete="off" aria-label="Dígito 4">
                            <input type="text" inputmode="numeric" maxlength="1" class="otp-input" data-index="4" autocomplete="off" aria-label="Dígito 5">
                            <input type="text" inputmode="numeric" maxlength="1" class="otp-input" data-index="5" autocomplete="off" aria-label="Dígito 6">
                        </div>

                        <!-- Botão de confirmar código -->
                        <button
                            type="submit"
                            id="btnConfirmarCodigo"
                            class="btn-submit d-flex align-items-center justify-content-center gap-2 mb-3"
                            disabled>
                            <i class="bi bi-check2-circle"></i>
                            <span>Confirmar e ativar conta</span>
                        </button>
                    </form>

                    <!-- Reenvio de código com contagem regressiva -->
                    <div class="text-center mt-3">
                        <p class="text-muted small mb-2">Não recebeu o código?</p>
                        <button
                            type="button"
                            id="btnReenviarCodigo"
                            class="btn btn-outline-custom d-inline-flex align-items-center gap-2"
                            disabled>
                            <i class="bi bi-arrow-repeat"></i>
                            <span id="textoReenviar">Reenviar código (<span id="contadorReenviar">30</span>s)</span>
                        </button>
                    </div>
                </div>

            </div>

            <!-- Footer -->
            <footer class="footer">
                <div>
                    © <?= date('Y') ?> Achei Profissional. Todos os direitos reservados.
                    <a href="#">Termos de uso</a>
                    <a href="#">Política de privacidade</a>
                    <a href="#">Ajuda</a>
                </div>
            </footer>

        </div>
    </main>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
    <!-- Script de Interação Assíncrona e OTP -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Elementos
            const btnEnviarCodigo = document.getElementById('btnEnviarCodigo');
            const btnEnviarTexto = document.getElementById('btnEnviarTexto');
            const sectionEnviarCodigo = document.getElementById('sectionEnviarCodigo');
            const sectionInformarCodigo = document.getElementById('sectionInformarCodigo');
            const btnReenviarCodigo = document.getElementById('btnReenviarCodigo');
            const alertSuccess = document.getElementById('alertSuccess');
            const alertSuccessMsg = document.getElementById('alertSuccessMsg');
            const alertError = document.getElementById('alertError');
            const alertErrorMsg = document.getElementById('alertErrorMsg');
            const formValidarCodigo = document.getElementById('formValidarCodigo');
            const btnConfirmarCodigo = document.getElementById('btnConfirmarCodigo');
            const codigoCompleto = document.getElementById('codigoCompleto');
            const otpInputs = document.querySelectorAll('.otp-input');

            // Configuração
            const URL_ENVIAR_CODIGO = '<?= base_url('receberemailvalidacao') ?>';
            const TEMPO_COUNTDOWN = 30; // 30 segundos solicitados
            let intervaloTimer = null;

            // CSRF Tokens
            function getCsrfData() {
                const tokenMeta = document.querySelector('meta[name="csrf-token"]');
                const headerMeta = document.querySelector('meta[name="csrf-header"]');
                return {
                    header: headerMeta ? headerMeta.getAttribute('content') : 'X-CSRF-TOKEN',
                    token: tokenMeta ? tokenMeta.getAttribute('content') : ''
                };
            }

            function atualizarCsrfToken(novoToken) {
                if (!novoToken) return;
                const tokenMeta = document.querySelector('meta[name="csrf-token"]');
                if (tokenMeta) tokenMeta.setAttribute('content', novoToken);

                const csrfInput = document.querySelector('input[name="<?= csrf_token() ?>"]');
                if (csrfInput) csrfInput.value = novoToken;
            }

            // Exibir mensagens
            function mostrarSucesso(mensagem) {
                alertError.classList.add('d-none');
                alertSuccessMsg.textContent = mensagem;
                alertSuccess.classList.remove('d-none');
                alertSuccess.classList.add('d-flex');
            }

            function mostrarErro(mensagem) {
                alertSuccess.classList.add('d-none');
                alertErrorMsg.textContent = mensagem;
                alertError.classList.remove('d-none');
                alertError.classList.add('d-flex');
            }

            function limparAlertas() {
                alertSuccess.classList.add('d-none');
                alertSuccess.classList.remove('d-flex');
                alertError.classList.add('d-none');
                alertError.classList.remove('d-flex');
            }

            // Iniciar contagem regressiva
            function iniciarCountdown(segundos = TEMPO_COUNTDOWN) {
                if (intervaloTimer) clearInterval(intervaloTimer);

                let restante = segundos;
                btnReenviarCodigo.disabled = true;
                btnReenviarCodigo.innerHTML = `
                    <i class="bi bi-arrow-repeat"></i>
                    <span>Reenviar código (<span id="contadorReenviar">${restante}</span>s)</span>
                `;

                intervaloTimer = setInterval(() => {
                    restante--;
                    const spanContador = document.getElementById('contadorReenviar');
                    if (spanContador) {
                        spanContador.textContent = restante;
                    }

                    if (restante <= 0) {
                        clearInterval(intervaloTimer);
                        intervaloTimer = null;
                        btnReenviarCodigo.disabled = false;
                        btnReenviarCodigo.innerHTML = `
                            <i class="bi bi-arrow-clockwise me-1"></i>
                            <span>Reenviar código agora</span>
                        `;
                    }
                }, 1000);
            }

            // Envio Assíncrono do Código
            async function enviarCodigoAssincrono(origemBtn) {
                limparAlertas();

                // Estado de Carregamento
                const textoOriginal = origemBtn.innerHTML;
                origemBtn.disabled = true;
                origemBtn.innerHTML = `
                    <span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                    <span>Enviando código...</span>
                `;

                const csrf = getCsrfData();
                const headers = {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Content-Type': 'application/json'
                };
                if (csrf.token) {
                    headers[csrf.header] = csrf.token;
                }

                try {
                    const response = await fetch(URL_ENVIAR_CODIGO, {
                        method: 'POST',
                        headers: headers,
                        body: JSON.stringify({})
                    });

                    const data = await response.json().catch(() => null);

                    // Se a resposta contiver novo CSRF token atualizado pelo CI4
                    if (data && data.csrf_token) {
                        atualizarCsrfToken(data.csrf_token);
                    }

                    if (!response.ok || (data && data.success === false)) {
                        const erroBackend = (data && (data.message || data.error)) 
                            ? (data.message || data.error) 
                            : 'Ocorreu um erro ao tentar enviar o código para o seu e-mail.';
                        throw new Error(erroBackend);
                    }

                    // Sucesso!
                    const mensagemSucesso = (data && data.message) 
                        ? data.message 
                        : 'Código de verificação enviado com sucesso para seu e-mail!';
                    mostrarSucesso(mensagemSucesso);

                    // Oculta botão inicial e exibe os campos para informar o código recebido
                    sectionEnviarCodigo.classList.add('d-none');
                    sectionInformarCodigo.classList.remove('d-none');

                    // Dispara a contagem de 15 segundos
                    iniciarCountdown(TEMPO_COUNTDOWN);

                    // Foco no primeiro campo do OTP
                    if (otpInputs.length > 0) {
                        otpInputs[0].focus();
                    }

                } catch (err) {
                    mostrarErro(err.message || 'Falha de comunicação com o servidor. Tente novamente.');
                    origemBtn.disabled = false;
                    origemBtn.innerHTML = textoOriginal;
                }
            }

            // Eventos dos botões de envio e reenvio
            btnEnviarCodigo.addEventListener('click', () => {
                enviarCodigoAssincrono(btnEnviarCodigo);
            });

            btnReenviarCodigo.addEventListener('click', () => {
                enviarCodigoAssincrono(btnReenviarCodigo);
            });

            // =========================================
            // COMPORTAMENTO DOS INPUTS OTP (6 DÍGITOS)
            // =========================================
            function atualizarCodigoFinal() {
                let codigo = '';
                otpInputs.forEach(input => codigo += input.value.trim());
                codigoCompleto.value = codigo;

                // Habilita o botão de confirmação apenas com os 6 dígitos preenchidos
                btnConfirmarCodigo.disabled = (codigo.length !== 6);
            }

            otpInputs.forEach((input, index) => {
                // Aceitar apenas números e avançar foco
                input.addEventListener('input', (e) => {
                    input.classList.remove('is-invalid');

                    // Limpa caracteres não numéricos
                    input.value = input.value.replace(/[^0-9]/g, '');

                    if (input.value.length > 0) {
                        input.classList.add('is-filled');
                        // Avança para o próximo campo se existir
                        if (index < otpInputs.length - 1) {
                            otpInputs[index + 1].focus();
                        }
                    } else {
                        input.classList.remove('is-filled');
                    }

                    atualizarCodigoFinal();
                });

                // Tecla Backspace para retornar foco
                input.addEventListener('keydown', (e) => {
                    if (e.key === 'Backspace' && input.value.length === 0 && index > 0) {
                        otpInputs[index - 1].focus();
                    }
                });

                // Suporte a Colar (Paste) ex: colar "123456" de uma vez
                input.addEventListener('paste', (e) => {
                    e.preventDefault();
                    const pasteData = (e.clipboardData || window.clipboardData).getData('text').trim();
                    const apenasNumeros = pasteData.replace(/[^0-9]/g, '').slice(0, 6);

                    if (apenasNumeros.length > 0) {
                        apenasNumeros.split('').forEach((num, i) => {
                            if (otpInputs[i]) {
                                otpInputs[i].value = num;
                                otpInputs[i].classList.remove('is-invalid');
                                otpInputs[i].classList.add('is-filled');
                            }
                        });

                        const proximoIndice = Math.min(apenasNumeros.length, otpInputs.length - 1);
                        otpInputs[proximoIndice].focus();
                        atualizarCodigoFinal();
                    }
                });
            });

            // Validação assíncrona do código recebido
            formValidarCodigo.addEventListener('submit', async (e) => {
                e.preventDefault();

                if (codigoCompleto.value.length !== 6) {
                    mostrarErro('Por favor, informe todos os 6 dígitos do código recebido.');
                    return;
                }

                limparAlertas();

                // Estado de carregamento no botão de confirmação
                const textoOriginalBtn = btnConfirmarCodigo.innerHTML;
                btnConfirmarCodigo.disabled = true;
                btnConfirmarCodigo.innerHTML = `
                    <span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                    <span>Validando código...</span>
                `;

                // Desabilita inputs enquanto valida
                otpInputs.forEach(input => input.disabled = true);

                const csrf = getCsrfData();
                const headers = {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Content-Type': 'application/json'
                };
                if (csrf.token) {
                    headers[csrf.header] = csrf.token;
                }

                try {
                    const response = await fetch(formValidarCodigo.action, {
                        method: 'POST',
                        headers: headers,
                        body: JSON.stringify({
                            codigo: codigoCompleto.value
                        })
                    });

                    const data = await response.json().catch(() => null);

                    if (data && data.csrf_token) {
                        atualizarCsrfToken(data.csrf_token);
                    }

                    if (!response.ok || (data && data.success === false)) {
                        const erroBackend = (data && (data.message || data.error))
                            ? (data.message || data.error)
                            : 'Código de verificação incorreto ou expirado.';
                        throw new Error(erroBackend);
                    }

                    // Sucesso!
                    const mensagemSucesso = (data && data.message)
                        ? data.message
                        : 'E-mail verificado com sucesso! Redirecionando...';
                    mostrarSucesso(mensagemSucesso);

                    btnConfirmarCodigo.innerHTML = `
                        <i class="bi bi-check-circle-fill me-2"></i>
                        <span>Conta ativada com sucesso!</span>
                    `;
                    btnConfirmarCodigo.style.background = '#198754';

                    const tipoUsuario = '<?= strtolower(session('usuario')->tipo) ?>';

                    const tipoUsuarioLink = 
                        (tipoUsuario === 'comum') 
                        ? 'usuariocomum'
                        : (tipoUsuario === 'profissional') ? 'profissional' : 'admin';

                    const urlDestino = (data && data.redirect)
                        ? data.redirect
                        : '<?= base_url() ?>' + tipoUsuarioLink + '/criarconta';
                    setTimeout(() => {
                        window.location.href = urlDestino;
                    }, 1200);

                } catch (err) {
                    mostrarErro(err.message || 'Falha ao validar o código. Tente novamente.');

                    // Reabilita os inputs com feedback de erro
                    otpInputs.forEach(input => {
                        input.disabled = false;
                        input.value = '';
                        input.classList.remove('is-filled');
                        input.classList.add('is-invalid');
                    });
                    codigoCompleto.value = '';

                    // Efeito de shake visual nos campos
                    const container = document.getElementById('otpContainer');
                    if (container) {
                        container.classList.add('shake');
                        setTimeout(() => container.classList.remove('shake'), 400);
                    }

                    btnConfirmarCodigo.disabled = true;
                    btnConfirmarCodigo.innerHTML = textoOriginalBtn;

                    // Foco no primeiro campo
                    if (otpInputs.length > 0) {
                        otpInputs[0].focus();
                    }
                }
            });
        });
    </script>
<?= $this->endSection() ?>
