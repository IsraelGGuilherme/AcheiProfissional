# Plataforma de Autônomos

Plataforma web desenvolvida como projeto de extensão acadêmica, com o objetivo de facilitar a conexão entre **clientes e profissionais autônomos**, permitindo que usuários encontrem profissionais, consultem informações sobre seus serviços, localização, horários de atendimento e avaliações.

O projeto é desenvolvido utilizando **PHP com CodeIgniter 4**, seguindo o padrão MVC, e utiliza **MySQL** como banco de dados.

## 🛠️ Tecnologias utilizadas

* PHP 8+
* CodeIgniter 4
* MySQL
* Composer
* Git / GitHub
* HTML, CSS e JavaScript
* Bootstrap

## 📋 Pré-requisitos

Antes de iniciar o projeto, certifique-se de possuir instalado:

* **PHP 8 ou superior**
* **Composer**
* **MySQL 8 ou superior**
* **Git**
* Um servidor web compatível, caso não seja utilizado o servidor embutido do PHP

Também é necessário que as extensões PHP exigidas pelo CodeIgniter 4 estejam habilitadas.

---

## 🚀 Instalação

### 1. Clonar o repositório

Clone o projeto utilizando Git:

```bash
git clone <URL_DO_REPOSITORIO>
```

Entre na pasta do projeto:

```bash
cd <NOME_DO_PROJETO>
```

### 2. Instalar as dependências

Execute:

```bash
composer install
```

Isso instalará as dependências necessárias do CodeIgniter 4.

---

## ⚙️ Configuração do ambiente

O CodeIgniter utiliza um arquivo `.env` para armazenar as configurações específicas do ambiente.

Na raiz do projeto existe um arquivo de exemplo chamado:

```text
env
```

Faça uma cópia dele:

```bash
cp env .env
```

No Windows, também é possível simplesmente copiar o arquivo `env` e renomeá-lo para:

```text
.env
```

### 3. Configurar o `.env`

Abra o arquivo `.env` e configure, inicialmente, o ambiente:

```ini
CI_ENVIRONMENT = development
```

Depois configure a conexão com o banco de dados:

```ini
database.default.hostname = localhost
database.default.database = nome_do_banco
database.default.username = usuario_do_banco
database.default.password = senha_do_banco
database.default.DBDriver = MySQLi
database.default.port = 3306
```

Substitua os valores de acordo com a configuração do seu ambiente.

Por exemplo:

```ini
database.default.hostname = localhost
database.default.database = plataforma_autonomos
database.default.username = root
database.default.password =
database.default.DBDriver = MySQLi
database.default.port = 3306
```

Depois, configure o serviço de envio de e-mails via **SMTP** (necessário para o envio dos códigos de verificação de conta e recuperação de senha):

```ini
#
# EMAIL
#

email.protocol = 'smtp'
email.SMTPHost = 'smtp.gmail.com'
email.SMTPPort = 587
email.SMTPUser = 'seu_email@gmail.com'
email.fromEmail = 'seu_email@gmail.com'
email.fromName = 'Achei Profissional'
email.SMTPPass = 'sua_senha_de_aplicativo'
email.SMTPCrypto = 'tls'
```

> **Nota:** Se você utilizar o Gmail, lembre-se de ativar a verificação em duas etapas e gerar uma **Senha de App** (App Password) para o `email.SMTPPass`.

> **Importante:** o arquivo `.env` não deve ser enviado ao GitHub, pois pode conter informações sensíveis, como credenciais do banco de dados e senhas de e-mail.

---

## 🗄️ Configuração do banco de dados

Antes de executar as migrations, crie o banco de dados no MySQL.

Por exemplo:

```sql
CREATE DATABASE plataforma_autonomos
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;
```

Depois, confira se o nome utilizado no `.env` corresponde ao banco criado:

```ini
database.default.database = plataforma_autonomos
```

---

## 🧱 Executando as migrations

Com o banco de dados criado e o `.env` configurado, execute as migrations do CodeIgniter.

Na raiz do projeto:

```bash
php spark migrate
```

O CodeIgniter executará as migrations pendentes e criará a estrutura do banco de dados.

Para verificar o estado das migrations:

```bash
php spark migrate:status
```

### Reverter a última migration

Caso seja necessário desfazer a última migration executada:

```bash
php spark migrate:rollback
```

> Tenha cuidado ao utilizar o rollback em um banco que já contenha dados.

---

## 🌱 Executando Seeds

Para inserir os dados iniciais essenciais da aplicação, utilize os **Seeders** do CodeIgniter 4 via Spark.

### Povoamento de Localidades (Obrigatório)

A plataforma necessita da base de dados de localidades (país, estados, municípios e bairros) para o cadastro de endereços e regiões de atendimento dos profissionais. Essa base conta com mais de 23.000 registros e é importada via dump SQL nativo:

```bash
php spark db:seed LocalidadesSeeder
```

> **Nota:** A base de dados utilizada pelo seeder fica armazenada em `app/Database/Seeds/data/localidades.sql`.

### Povoamento de Categorias de Serviços (Obrigatório)

A plataforma também precisa de uma lista prévia de categorias (como Pedreiro, Eletricista, Encanador, Diarista) para que os profissionais possam selecionar os serviços que prestam no momento do cadastro. Para inserir essas categorias padrões, execute:

```bash
php spark db:seed CategoriasSeeder
```

### Outros Seeds

Para executar outros seeders que venham a ser criados:

```bash
php spark db:seed NomeDoSeeder
```


---

## ▶️ Executando o projeto

Após configurar o banco e executar as migrations, o projeto pode ser iniciado utilizando o servidor de desenvolvimento do CodeIgniter:

```bash
php spark serve
```

Por padrão, a aplicação ficará disponível em:

```text
http://localhost:8080
```

Para utilizar outra porta:

```bash
php spark serve --port 8081
```

---

## 📁 Estrutura principal do projeto

A estrutura segue o padrão do CodeIgniter 4:

```text
├── app/
│   ├── Config/
│   ├── Controllers/
│   ├── Database/
│   │   ├── Migrations/
│   │   └── Seeds/
│   ├── Models/
│   ├── Views/
│   └── ...
│
├── public/
├── writable/
├── tests/
├── .env
├── composer.json
├── env
└── spark
```

### Principais diretórios

**`app/`**
Contém o código principal da aplicação.

**`app/Controllers/`**
Contém os controllers responsáveis por receber as requisições e coordenar as operações da aplicação.

**`app/Models/`**
Contém os Models utilizados para comunicação e manipulação dos dados.

**`app/Views/`**
Contém as interfaces e páginas da aplicação.

**`app/Database/Migrations/`**
Contém as migrations responsáveis pela criação e alteração da estrutura do banco de dados.

**`app/Database/Seeds/`**
Contém os Seeders utilizados para inserir dados iniciais no banco.

**`public/`**
Diretório público da aplicação.

**`writable/`**
Diretório utilizado pelo CodeIgniter para arquivos que precisam ser gravados durante a execução da aplicação, como logs e cache.

---

## 🔄 Fluxo para configurar o projeto em uma nova máquina

De forma resumida:

```bash
git clone <URL_DO_REPOSITORIO>
cd <NOME_DO_PROJETO>

composer install

cp env .env
```

Depois:

1. Criar o banco de dados MySQL.
2. Configurar as credenciais no `.env` (banco de dados e e-mail SMTP).
3. Executar as migrations.
4. Povoar a base de localidades com a Seeder.
5. Iniciar o servidor.

```bash
php spark migrate
php spark db:seed LocalidadesSeeder
php spark db:seed CategoriasSeeder
php spark serve
```

A aplicação estará disponível em:

```text
http://localhost:8080
```

---

## 👥 Desenvolvimento

O projeto é desenvolvido de forma colaborativa utilizando Git e GitHub.

Recomenda-se criar branches para novas funcionalidades e manter commits pequenos e descritivos.

Exemplo:

```bash
git checkout -b feature/nova-funcionalidade
```

Após concluir as alterações:

```bash
git add .
git commit -m "feat: adiciona nova funcionalidade"
git push origin feature/nova-funcionalidade
```

---

## 📄 Licença

Este projeto foi desenvolvido para fins acadêmicos como parte de um projeto de extensão.
